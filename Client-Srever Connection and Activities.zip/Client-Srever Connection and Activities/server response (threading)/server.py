import socket
import threading

terminate_msg="End"
data=16
format="utf-8"
port=5060
hostname=socket.gethostname()
host_addr=socket.gethostbyname(hostname)
server_socket_address=(host_addr,port)
server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(server_socket_address)
server.listen()
print("Server is listenting")

def handler(conn,addr):
    print("Connected to: ",addr)
    connected=True

    while connected:
        initial=conn.recv(data).decode(format)
        print("Length of the mesaage to be sent ",initial)

        if initial:
            msg_len=int(initial)
            msg=conn.recv(msg_len).decode(format)

            if msg==terminate_msg:
                print("Terminating connection with ",addr)
                conn.send("Nice to meet you".encode(format))
                connected=False

            else:
                vowels="aeiouAEIOU"
                count=0
                for i in msg:
                    if i in vowels:
                        count+=1
                if count==0:
                    conn.send("Not enough vowels".encode(format))
                elif count<=2:
                    conn.send("Enough vowels I guess".encode(format))
                else:
                    conn.send("Too many vowels".encode(format))
    conn.close()

while True:
    conn,addr=server.accept()
    thread=threading.Thread(target=handler, args=(conn,addr))
    thread.start()