import socket
port=5060
format="utf-8"
data=16
terminate_msg="End"
hostname=socket.gethostname()
host_addr=socket.gethostbyname(hostname)
server_socket_address=(host_addr,port)
client=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client.connect(server_socket_address)


def send_msg(msg):
    message=msg.encode(format)
    msg_len=len(message)
    msg_len=str(msg_len).encode(format)
    msg_len+=b" "*(data-len(msg_len))

    client.send(msg_len)
    client.send(message)

    print(client.recv(2048).decode(format))

msg=f"IP Address of the client is {host_addr} and the device name is {hostname}"
send_msg(msg)
send_msg(terminate_msg)


