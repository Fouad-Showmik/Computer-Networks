import socket
terminate_msg="End"
data=16
format="utf-8"
port=5061
hostname=socket.gethostname()
host_addr=socket.gethostbyname(hostname)
server_socket_address=(host_addr,port)
server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(server_socket_address)
server.listen()
print("Server is listenting")

while True:
    conn,addr=server.accept()
    print("Connected to: ",addr)

    connected=True
    while connected:
        initial=conn.recv(data).decode(format)
        print("Length of the mesaage to be sent ",initial)

        if initial:
            msg_len=int(initial)
            msg=conn.recv(msg_len).decode(format)

            if msg==terminate_msg:
                print("Terminating connection with ",addr)
                conn.send("Nice to meet you".encode(format))
                connected=False

            else:
                salary=0
                msg=int(msg)
                if msg<=40:
                    salary=(msg*200)
                    conn.send(f"Salary is {salary} TK".encode(format))
                else:
                    hours=(msg-40)
                    salary=8000+(hours*300)
                    conn.send(f"Salary is {salary} TK".encode(format))
    conn.close()